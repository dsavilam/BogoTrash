package com.example.bogotrash.model

data class Reward(
    val id: Int,
    val points: Int,
    val name: String,
    val description: String,
    val imageName: String
)
