package com.example.bogotrash.model

data class UserRanking(
    val name: String,
    val level: String,
    val points: Int
)
